# Univaq-Thesis-GM
## Minimal Ecore rappresenting a Microservice Architecture


