/*
 * 
 */
package MicroservicesArchitecture.diagram.edit.helpers;

import org.eclipse.gmf.tooling.runtime.edit.helpers.GeneratedEditHelperBase;

/**
 * @generated
 */
public class MicroservicesArchitectureBaseEditHelper extends GeneratedEditHelperBase {

}
