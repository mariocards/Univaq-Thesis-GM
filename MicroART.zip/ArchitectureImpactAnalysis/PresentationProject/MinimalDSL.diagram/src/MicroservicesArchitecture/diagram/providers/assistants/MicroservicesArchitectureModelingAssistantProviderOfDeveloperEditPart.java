/*
 * 
 */
package MicroservicesArchitecture.diagram.providers.assistants;

/**
 * @generated
 */
public class MicroservicesArchitectureModelingAssistantProviderOfDeveloperEditPart
		extends MicroservicesArchitecture.diagram.providers.MicroservicesArchitectureModelingAssistantProvider {

}
