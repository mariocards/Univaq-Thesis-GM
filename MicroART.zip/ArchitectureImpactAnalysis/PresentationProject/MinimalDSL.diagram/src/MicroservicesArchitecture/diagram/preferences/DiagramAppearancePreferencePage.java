/*
 * 
 */
package MicroservicesArchitecture.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.AppearancePreferencePage;

/**
 * @generated
 */
public class DiagramAppearancePreferencePage extends AppearancePreferencePage {

	/**
	* @generated
	*/
	public DiagramAppearancePreferencePage() {
		setPreferenceStore(MicroservicesArchitecture.diagram.part.MicroservicesArchitectureDiagramEditorPlugin
				.getInstance().getPreferenceStore());
	}
}
