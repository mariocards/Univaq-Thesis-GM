package it.univaq.architecture.recovery.model;

public class Develeper {

}
