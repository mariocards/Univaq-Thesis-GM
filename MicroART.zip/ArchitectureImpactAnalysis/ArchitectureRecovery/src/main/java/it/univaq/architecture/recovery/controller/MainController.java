//package it.univaq.architecture.recovery.controller;
//
//import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.stereotype.Controller;
//
//@ComponentScan(basePackages = { "it.univaq.architecture.recovery.service.impl.*" })
//@EnableAutoConfiguration
//@Configuration
//@Controller
//public class MainController {
//
//	@Autowired
//	private String
//	
//}
